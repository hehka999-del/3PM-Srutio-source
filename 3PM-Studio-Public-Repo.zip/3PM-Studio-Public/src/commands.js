const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType
} = require('discord.js');

const commands = [
  new SlashCommandBuilder().setName('help').setDescription('Show the 3PM Studio command list'),
  new SlashCommandBuilder().setName('ping').setDescription('Show bot latency'),
  new SlashCommandBuilder().setName('uptime').setDescription('Show bot uptime'),
  new SlashCommandBuilder().setName('server').setDescription('Show server information'),
  new SlashCommandBuilder().setName('user').setDescription('Show a user profile').addUserOption(o=>o.setName('user').setDescription('User')),
  new SlashCommandBuilder().setName('avatar').setDescription('Show a user avatar').addUserOption(o=>o.setName('user').setDescription('User')),
  new SlashCommandBuilder().setName('rank').setDescription('Show a rank card').addUserOption(o=>o.setName('user').setDescription('User')).addStringOption(o=>o.setName('color').setDescription('Card color').addChoices(
    {name:'Orange',value:'orange'},{name:'Blue',value:'blue'},{name:'Purple',value:'purple'},{name:'Green',value:'green'},{name:'Red',value:'red'}
  )).addIntegerOption(o=>o.setName('add_levels').setDescription('Add levels (Administrator only)').setMinValue(1).setMaxValue(1000)),
  new SlashCommandBuilder().setName('top').setDescription('Show the server ranking'),
  new SlashCommandBuilder().setName('coinflip').setDescription('Flip a coin'),
  new SlashCommandBuilder().setName('rps').setDescription('Play rock paper scissors'),
  new SlashCommandBuilder().setName('tictactoe').setDescription('Play tic-tac-toe').addUserOption(o=>o.setName('opponent').setDescription('Opponent').setRequired(true)),
  new SlashCommandBuilder().setName('poll').setDescription('Create a poll').addStringOption(o=>o.setName('question').setDescription('Question').setRequired(true)).addStringOption(o=>o.setName('option1').setDescription('Option 1').setRequired(true)).addStringOption(o=>o.setName('option2').setDescription('Option 2').setRequired(true)).addIntegerOption(o=>o.setName('minutes').setDescription('Duration in minutes').setMinValue(1).setMaxValue(1440).setRequired(true)).addStringOption(o=>o.setName('option3').setDescription('Option 3')).addStringOption(o=>o.setName('option4').setDescription('Option 4')),
  new SlashCommandBuilder().setName('ticket').setDescription('Create a support ticket'),
  new SlashCommandBuilder().setName('ticket-setup').setDescription('Create the ticket category'),
  new SlashCommandBuilder().setName('stats-setup').setDescription('Create public server statistics'),
  new SlashCommandBuilder().setName('table').setDescription('Open the table builder'),
  new SlashCommandBuilder().setName('announcement').setDescription('Publish an announcement').addStringOption(o=>o.setName('text').setDescription('Announcement text').setRequired(true)).addChannelOption(o=>o.setName('channel').setDescription('Target channel')),
  new SlashCommandBuilder().setName('logs').setDescription('Configure logs').addChannelOption(o=>o.setName('channel').setDescription('Log channel').addChannelTypes(ChannelType.GuildText)),
  new SlashCommandBuilder().setName('setup').setDescription('Run the basic setup'),
  new SlashCommandBuilder().setName('settings').setDescription('Show current settings'),
  new SlashCommandBuilder().setName('language').setDescription('Choose your language'),
  new SlashCommandBuilder().setName('languages').setDescription('Open the language selector'),
  new SlashCommandBuilder().setName('automod').setDescription('Configure AutoMod').addStringOption(o=>o.setName('action').setDescription('status/on/off')).addStringOption(o=>o.setName('rule').setDescription('links/invites/caps/mentions/zalgo/repeated/spam')),
  new SlashCommandBuilder().setName('filter').setDescription('Manage the bad-word filter').addStringOption(o=>o.setName('action').setDescription('add/remove/on/off/list').setRequired(true)).addStringOption(o=>o.setName('word').setDescription('Word')),
  new SlashCommandBuilder().setName('botguard').setDescription('Toggle bot guard'),
  new SlashCommandBuilder().setName('roles').setDescription('Manage roles').addStringOption(o=>o.setName('action').setDescription('list/create/delete/give/remove/rename').setRequired(true)).addRoleOption(o=>o.setName('role').setDescription('Role')).addUserOption(o=>o.setName('user').setDescription('User')).addStringOption(o=>o.setName('name').setDescription('Role name')).addStringOption(o=>o.setName('color').setDescription('HEX color')),
  new SlashCommandBuilder().setName('temprole').setDescription('Give a temporary role').addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)).addRoleOption(o=>o.setName('role').setDescription('Role').setRequired(true)).addIntegerOption(o=>o.setName('minutes').setDescription('Minutes').setMinValue(1).setMaxValue(40320).setRequired(true)),
  new SlashCommandBuilder().setName('warn').setDescription('Warn a member').addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason').setRequired(true)),
  new SlashCommandBuilder().setName('unwarn').setDescription('Remove the latest warning').addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)),
  new SlashCommandBuilder().setName('warnings').setDescription('View warnings').addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)),
  new SlashCommandBuilder().setName('mute').setDescription('Mute a member').addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)).addIntegerOption(o=>o.setName('minutes').setDescription('Minutes').setMinValue(1).setMaxValue(40320).setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason')),
  new SlashCommandBuilder().setName('unmute').setDescription('Unmute a member').addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)),
  new SlashCommandBuilder().setName('timeout').setDescription('Apply Discord timeout').addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)).addIntegerOption(o=>o.setName('minutes').setDescription('Minutes').setMinValue(1).setMaxValue(40320).setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason')),
  new SlashCommandBuilder().setName('untimeout').setDescription('Remove Discord timeout').addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)),
  new SlashCommandBuilder().setName('kick').setDescription('Kick a member').addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason')),
  new SlashCommandBuilder().setName('ban').setDescription('Ban a member').addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason')),
  new SlashCommandBuilder().setName('clear').setDescription('Delete recent messages').addIntegerOption(o=>o.setName('amount').setDescription('Amount').setMinValue(1).setMaxValue(100).setRequired(true)),
  new SlashCommandBuilder().setName('lock').setDescription('Lock the current channel'),
  new SlashCommandBuilder().setName('unlock').setDescription('Unlock the current channel'),
  new SlashCommandBuilder().setName('slowmode').setDescription('Set slowmode').addIntegerOption(o=>o.setName('seconds').setDescription('Seconds').setMinValue(0).setMaxValue(21600).setRequired(true)),
  new SlashCommandBuilder().setName('cases').setDescription('Show recent moderation cases').addIntegerOption(o=>o.setName('limit').setDescription('1-20').setMinValue(1).setMaxValue(20)),
  new SlashCommandBuilder().setName('warnqueue').setDescription('Show members at 3/3 warnings'),
  new SlashCommandBuilder().setName('panel').setDescription('Open the administration panel')
].map(c=>c.toJSON());

const adminOnly = new Set(['setup','settings','logs','automod','filter','botguard','roles','temprole','ticket-setup','stats-setup','table','announcement','panel','ban']);
const modOnly = new Set(['warn','unwarn','warnings','mute','unmute','timeout','untimeout','kick','clear','lock','unlock','slowmode','cases','warnqueue']);

module.exports = { commands, adminOnly, modOnly, PermissionFlagsBits };
